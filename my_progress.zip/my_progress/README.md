# my_progress

Productivity & AI Progress Tracker — Flutter app scaffold.

## Setup

```bash
flutter pub get

# Generates lib/models/log_entry.g.dart and chat_message.g.dart
# (Hive TypeAdapters) from the @HiveType/@HiveField annotations.
flutter pub run build_runner build --delete-conflicting-outputs

flutter run
```

## Configuring the default Gemini key

`GeminiService.defaultGeminiKey` is read from a compile-time define,
**not** hardcoded, so you don't accidentally commit a real key:

```bash
flutter run --dart-define=DEFAULT_GEMINI_KEY=your_key_here
```

### ⚠️ Before shipping this to real users

Any key compiled into a client app — including via `--dart-define` —
can be extracted from the release binary through static analysis.
Treat `DEFAULT_GEMINI_KEY` as a **public, low-privilege promotional
quota**, not a secret:

- Create it in a throwaway Google Cloud project.
- Set a strict daily quota and a hard billing cap in Google Cloud
  Console so a leaked key can't run up real cost.
- The in-app "10 free queries" counter (`SecureStorageService`) is a
  **UX gate**, not a security boundary — it lives on-device and can
  be bypassed by clearing app data or reinstalling.
- For a production app with real cost exposure, proxy default-tier
  requests through your own backend (e.g. a small Cloud Function)
  instead of shipping any Gemini key client-side at all.

## Architecture

| Layer | Notes |
|---|---|
| `models/` | Hive-annotated data classes (`LogEntry`, `ChatMessage`) |
| `services/` | `HiveService` (local DB), `SecureStorageService` (Keychain/Keystore), `EncryptionService` (AES-256 for note content), `CategorizationService` (offline heuristics), `GeminiService` (hybrid key AI calls) |
| `theme/` | `AppTheme` — Material 3 light/dark, gradients, streak-grid coloring |
| `widgets/` | Reusable UI: `AnimatedBottomNav`, `StreakGrid`, `ConnectGeminiModal` |
| `screens/` | One folder per tab: home, exam, pdf_studio, ai_chat, profile |

## Data storage summary

- **Logs & chat messages** → Hive (`log_entries_box`, `ai_chat_box`), unencrypted on disk — fine for non-sensitive productivity data.
- **API keys & free-query counter** → `flutter_secure_storage`, hardware-backed.
- **PDF study notes** → AES-256-CBC encrypted via `EncryptionService` before persistence (persistence layer left as a `TODO` hook in `pdf_studio_screen.dart` — wire it to a dedicated Hive box keyed by filename when you add multi-document note history).

## Known scaffold gaps to fill in before release

- PDF Studio notes are currently session-only (encrypt/decrypt round-trip is wired, but not yet saved to a Hive box across app restarts).
- No automated tests included — add `test/` coverage for `GeminiService`'s quota logic and `CategorizationService` at minimum.
- `flutter_pdfview` requires Android `minSdkVersion 21+` and adding `io.flutter.embedded_views_preview` — check the package's platform setup docs.
