import 'package:hive/hive.dart';

part 'log_entry.g.dart';

/// The category of a logged activity. Drives the categorization
/// service's auto-tagging and the streak grid's intensity coloring.
@HiveType(typeId: 0)
enum LogType {
  @HiveField(0)
  study,
  @HiveField(1)
  task,
  @HiveField(2)
  exam,
  @HiveField(3)
  other,
}

/// A single productivity log entry (a study session, completed task,
/// or freeform note) persisted locally in Hive.
@HiveType(typeId: 1)
class LogEntry extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String? notes;

  @HiveField(3)
  LogType type;

  @HiveField(4)
  DateTime timestamp;

  /// Duration in minutes, used for the streak grid intensity and
  /// daily totals. Null for simple task check-offs.
  @HiveField(5)
  int? durationMinutes;

  /// Optional subject/tag, e.g. "Calculus II" or "Client Report".
  @HiveField(6)
  String? subject;

  @HiveField(7)
  bool completed;

  LogEntry({
    required this.id,
    required this.title,
    this.notes,
    required this.type,
    required this.timestamp,
    this.durationMinutes,
    this.subject,
    this.completed = true,
  });
}
