import 'package:hive/hive.dart';

part 'chat_message.g.dart';

@HiveType(typeId: 2)
enum MessageRole {
  @HiveField(0)
  user,
  @HiveField(1)
  ai,
  @HiveField(2)
  system,
}

/// A single message in the app's one persistent AI conversation thread.
@HiveType(typeId: 3)
class ChatMessage extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String content;

  @HiveField(2)
  MessageRole role;

  @HiveField(3)
  DateTime timestamp;

  /// True while a response is being streamed/generated - lets the UI
  /// render a typing indicator bubble that gets replaced in place.
  @HiveField(4)
  bool isPending;

  /// True if this message represents a failed request (e.g. rate
  /// limited), so the UI can show a retry affordance.
  @HiveField(5)
  bool isError;

  ChatMessage({
    required this.id,
    required this.content,
    required this.role,
    required this.timestamp,
    this.isPending = false,
    this.isError = false,
  });
}
