import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import '../models/log_entry.dart';
import '../models/chat_message.dart';

/// Owns Hive initialization and box access. All screens/services go
/// through this singleton rather than opening boxes directly, so the
/// app has a single source of truth for box lifecycles.
class HiveService {
  HiveService._internal();
  static final HiveService instance = HiveService._internal();

  static const String logBoxName = 'log_entries_box';
  static const String chatBoxName = 'ai_chat_box';

  late Box<LogEntry> logBox;
  late Box<ChatMessage> chatBox;

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;

    final appDir = await getApplicationDocumentsDirectory();
    Hive.init(appDir.path);

    Hive.registerAdapter(LogTypeAdapter());
    Hive.registerAdapter(LogEntryAdapter());
    Hive.registerAdapter(MessageRoleAdapter());
    Hive.registerAdapter(ChatMessageAdapter());

    logBox = await Hive.openBox<LogEntry>(logBoxName);
    chatBox = await Hive.openBox<ChatMessage>(chatBoxName);

    _initialized = true;
  }

  // ---- Log entries ----

  List<LogEntry> get allLogEntries => logBox.values.toList()
    ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

  Future<void> addLogEntry(LogEntry entry) => logBox.put(entry.id, entry);

  Future<void> updateLogEntry(LogEntry entry) => entry.save();

  Future<void> deleteLogEntry(String id) => logBox.delete(id);

  List<LogEntry> logEntriesForDay(DateTime day) {
    final start = DateTime(day.year, day.month, day.day);
    final end = start.add(const Duration(days: 1));
    return allLogEntries
        .where((e) => e.timestamp.isAfter(start) && e.timestamp.isBefore(end))
        .toList();
  }

  // ---- Chat (single persistent thread) ----

  List<ChatMessage> get chatHistory => chatBox.values.toList()
    ..sort((a, b) => a.timestamp.compareTo(b.timestamp));

  Future<void> addChatMessage(ChatMessage message) => chatBox.put(message.id, message);

  Future<void> updateChatMessage(ChatMessage message) => message.save();

  Future<void> deleteChatMessage(String id) => chatBox.delete(id);

  Future<void> clearChatThread() => chatBox.clear();
}
