import '../models/log_entry.dart';

/// Lightweight, fully-offline heuristic categorizer that suggests a
/// [LogType] and intensity level for the streak grid based on a log
/// entry's title/notes. Kept rule-based (no network call) so quick
/// logging never blocks on connectivity or AI quota.
class CategorizationService {
  CategorizationService._internal();
  static final CategorizationService instance = CategorizationService._internal();

  static const _studyKeywords = [
    'study', 'read', 'chapter', 'lecture', 'notes', 'review', 'flashcard',
    'course', 'exam', 'quiz', 'practice',
  ];

  static const _taskKeywords = [
    'task', 'todo', 'finish', 'submit', 'complete', 'fix', 'build',
    'deploy', 'meeting', 'email', 'call',
  ];

  /// Suggests a [LogType] from freeform text. Defaults to
  /// [LogType.other] when nothing matches.
  LogType suggestType(String text) {
    final lower = text.toLowerCase();
    if (_studyKeywords.any(lower.contains)) return LogType.study;
    if (_taskKeywords.any(lower.contains)) return LogType.task;
    return LogType.other;
  }

  /// Buckets a day's total logged minutes into a 0-4 intensity level,
  /// mirroring GitHub's contribution-graph shading, for
  /// [StreakGrid] to color cells with.
  int intensityForMinutes(int totalMinutes) {
    if (totalMinutes <= 0) return 0;
    if (totalMinutes < 30) return 1;
    if (totalMinutes < 60) return 2;
    if (totalMinutes < 120) return 3;
    return 4;
  }

  /// Aggregates total minutes per calendar day for the streak grid.
  Map<DateTime, int> dailyMinutes(List<LogEntry> entries) {
    final map = <DateTime, int>{};
    for (final e in entries) {
      final day = DateTime(e.timestamp.year, e.timestamp.month, e.timestamp.day);
      map[day] = (map[day] ?? 0) + (e.durationMinutes ?? 0);
    }
    return map;
  }
}
