import 'package:google_generative_ai/google_generative_ai.dart';
import 'secure_storage_service.dart';

/// Thrown when the embedded free-tier key has been exhausted and the
/// user has not connected a personal key yet. The UI catches this to
/// trigger [ConnectGeminiModal].
class GeminiQuotaExceededException implements Exception {
  const GeminiQuotaExceededException();
}

/// Thrown when Gemini returns a 429 / rate-limit style error so the
/// UI can show a friendly toast instead of a raw stack trace.
class GeminiRateLimitException implements Exception {
  final String message;
  const GeminiRateLimitException(this.message);
}

enum GeminiKeySource { customKey, defaultKey }

class GeminiQueryResult {
  final String text;
  final GeminiKeySource source;
  final int? remainingFreeQueries;
  const GeminiQueryResult(this.text, this.source, this.remainingFreeQueries);
}

/// Wraps the Gemini SDK with the app's hybrid key strategy:
///
/// 1. If the user has saved a personal key, ALWAYS use it (unlimited,
///    billed to their own Google account).
/// 2. Otherwise, use the embedded default key for up to
///    [freeQueryLimit] queries total, tracked in secure storage.
/// 3. Once the limit is hit with no personal key present, block the
///    request and surface [GeminiQuotaExceededException] so the UI
///    can prompt the user to connect their own key.
///
/// SECURITY NOTE (read before shipping): any key compiled into a
/// client binary — including via --dart-define — can be extracted by
/// a motivated attacker through static analysis of the release APK/IPA.
/// [defaultGeminiKey] should therefore be a low-privilege, tightly
/// rate-limited, billing-capped key from a throwaway Google Cloud
/// project, treated as a public promotional quota rather than a
/// secret. For a production app with real cost exposure, proxy
/// default-tier requests through your own backend instead of shipping
/// the key client-side; this in-app soft counter is a UX gate, not a
/// security boundary, since it can be bypassed by clearing app data.
class GeminiService {
  GeminiService._internal();
  static final GeminiService instance = GeminiService._internal();

  /// Replace with a restricted, budget-capped key before release.
  /// See the security note in this file's header comment.
  static const String defaultGeminiKey = String.fromEnvironment(
    'DEFAULT_GEMINI_KEY',
    defaultValue: 'REPLACE_WITH_YOUR_OWN_RESTRICTED_DEFAULT_KEY',
  );

  static const int freeQueryLimit = 10;
  static const String modelName = 'gemini-1.5-flash';

  final _storage = SecureStorageService.instance;

  GenerativeModel _modelFor(String apiKey) =>
      GenerativeModel(model: modelName, apiKey: apiKey);

  Future<int> remainingFreeQueries() async {
    final used = await _storage.getFreeQueryCount();
    final remaining = freeQueryLimit - used;
    return remaining < 0 ? 0 : remaining;
  }

  Future<bool> get isUsingCustomKey => _storage.hasCustomGeminiKey();

  /// Sends [prompt] with the app's full chat history as context.
  /// Throws [GeminiQuotaExceededException] if the free tier is spent
  /// and no personal key is set, or [GeminiRateLimitException] on a
  /// 429 from Google.
  Future<GeminiQueryResult> sendMessage(
    String prompt, {
    List<Content> history = const [],
  }) async {
    final customKey = await _storage.getCustomGeminiKey();

    if (customKey != null && customKey.isNotEmpty) {
      final text = await _generate(customKey, prompt, history);
      return GeminiQueryResult(text, GeminiKeySource.customKey, null);
    }

    final used = await _storage.getFreeQueryCount();
    if (used >= freeQueryLimit) {
      throw const GeminiQuotaExceededException();
    }

    final text = await _generate(defaultGeminiKey, prompt, history);
    await _storage.incrementFreeQueryCount();
    final remaining = freeQueryLimit - (used + 1);
    return GeminiQueryResult(text, GeminiKeySource.defaultKey, remaining);
  }

  Future<String> _generate(
    String apiKey,
    String prompt,
    List<Content> history,
  ) async {
    try {
      final model = _modelFor(apiKey);
      final chat = model.startChat(history: history);
      final response = await chat.sendMessage(Content.text(prompt));
      return response.text ?? '(No response text returned.)';
    } catch (e) {
      final message = e.toString().toLowerCase();
      if (message.contains('429') ||
          message.contains('rate') ||
          message.contains('quota')) {
        throw GeminiRateLimitException(
          'Gemini rate limit reached. Please wait a moment and try again.',
        );
      }
      rethrow;
    }
  }

  /// Validates a user-entered key format before saving. Real
  /// validity is confirmed by the first successful call.
  bool looksLikeValidKey(String key) =>
      key.trim().startsWith('AIzaSy') && key.trim().length >= 30;

  Future<void> saveCustomKey(String key) => _storage.setCustomGeminiKey(key);

  Future<void> removeCustomKey() => _storage.clearCustomGeminiKey();
}
