import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'secure_storage_service.dart';

/// Encrypts sensitive user content (PDF study notes, chat content if
/// ever exported) at rest using AES-256-CBC. Hive's default box
/// storage is NOT encrypted on disk, so any field a user would
/// consider private should be passed through this service before
/// being written to a Hive box.
///
/// The AES key itself is derived from a random salt that lives in
/// [SecureStorageService] (Keychain / Keystore-backed), so the key
/// material never lives in plaintext app storage.
class EncryptionService {
  EncryptionService._internal();
  static final EncryptionService instance = EncryptionService._internal();

  enc.Key? _cachedKey;

  Future<enc.Key> _getKey() async {
    if (_cachedKey != null) return _cachedKey!;
    final salt = await SecureStorageService.instance.getOrCreateEncryptionSalt(_generateSalt);
    // Derive a 32-byte AES-256 key from the salt via SHA-256.
    final digest = sha256.convert(utf8.encode(salt));
    _cachedKey = enc.Key(Uint8ListFromDigest(digest));
    return _cachedKey!;
  }

  String _generateSalt() {
    final rand = Random.secure();
    final bytes = List<int>.generate(32, (_) => rand.nextInt(256));
    return base64Url.encode(bytes);
  }

  /// Encrypts [plainText], returning `iv:cipherText` (both base64),
  /// safe to store as a plain string in a Hive field.
  Future<String> encryptText(String plainText) async {
    final key = await _getKey();
    final iv = enc.IV.fromSecureRandom(16);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encrypt(plainText, iv: iv);
    return '${iv.base64}:${encrypted.base64}';
  }

  /// Reverses [encryptText]. Returns an empty string (rather than
  /// throwing) if the payload is malformed, so a corrupted record
  /// never crashes the UI.
  Future<String> decryptText(String payload) async {
    try {
      final parts = payload.split(':');
      if (parts.length != 2) return '';
      final key = await _getKey();
      final iv = enc.IV.fromBase64(parts[0]);
      final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
      return encrypter.decrypt64(parts[1], iv: iv);
    } catch (_) {
      return '';
    }
  }
}

List<int> Uint8ListFromDigest(Digest digest) => digest.bytes;
