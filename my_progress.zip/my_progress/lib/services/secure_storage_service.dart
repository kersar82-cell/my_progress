import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Thin wrapper around [FlutterSecureStorage] centralizing every key
/// name used for sensitive data so nothing sensitive ever touches
/// Hive (which is unencrypted on disk by default) or SharedPreferences.
///
/// Backing store: Keychain on iOS, EncryptedSharedPreferences /
/// Android Keystore-wrapped storage on Android.
class SecureStorageService {
  SecureStorageService._internal();
  static final SecureStorageService instance = SecureStorageService._internal();

  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
  );

  static const String _keyCustomGeminiKey = 'custom_gemini_api_key';
  static const String _keyFreeQueryCount = 'free_queries_count';
  static const String _keyEncryptionSalt = 'local_encryption_salt';

  // ---- Custom Gemini API key ----

  Future<String?> getCustomGeminiKey() => _storage.read(key: _keyCustomGeminiKey);

  Future<void> setCustomGeminiKey(String key) =>
      _storage.write(key: _keyCustomGeminiKey, value: key.trim());

  Future<void> clearCustomGeminiKey() => _storage.delete(key: _keyCustomGeminiKey);

  Future<bool> hasCustomGeminiKey() async {
    final key = await getCustomGeminiKey();
    return key != null && key.isNotEmpty;
  }

  // ---- Free query counter (default-key rate limiting) ----

  Future<int> getFreeQueryCount() async {
    final raw = await _storage.read(key: _keyFreeQueryCount);
    return int.tryParse(raw ?? '0') ?? 0;
  }

  Future<void> incrementFreeQueryCount() async {
    final current = await getFreeQueryCount();
    await _storage.write(key: _keyFreeQueryCount, value: (current + 1).toString());
  }

  Future<void> resetFreeQueryCount() =>
      _storage.write(key: _keyFreeQueryCount, value: '0');

  // ---- Local encryption salt (used by EncryptionService) ----

  Future<String> getOrCreateEncryptionSalt(String Function() generator) async {
    final existing = await _storage.read(key: _keyEncryptionSalt);
    if (existing != null && existing.isNotEmpty) return existing;
    final generated = generator();
    await _storage.write(key: _keyEncryptionSalt, value: generated);
    return generated;
  }

  /// Wipes all sensitive data. Called from Profile > "Reset Security".
  Future<void> wipeAll() => _storage.deleteAll();
}
