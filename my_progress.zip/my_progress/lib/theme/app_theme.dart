import 'package:flutter/material.dart';

/// Centralized visual language for the app: color seeds, gradients,
/// and shared curves so every screen composes from the same palette
/// instead of hardcoding one-off colors.
class AppTheme {
  AppTheme._();

  static const Color seed = Color(0xFF6C5CE7); // Indigo/violet accent
  static const Color success = Color(0xFF00B894);
  static const Color warning = Color(0xFFFDCB6E);
  static const Color danger = Color(0xFFD63031);

  static const Curve cardCurve = Curves.easeOutCubic;
  static const Duration cardAnimationDuration = Duration(milliseconds: 320);

  static const List<Color> primaryGradient = [Color(0xFF6C5CE7), Color(0xFF8E7CFF)];
  static const List<Color> streakGradientDark = [Color(0xFF161B22), Color(0xFF39D353)];
  static const List<Color> streakGradientLight = [Color(0xFFEBEDF0), Color(0xFF216E39)];

  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light);
    return _base(scheme).copyWith(
      scaffoldBackgroundColor: const Color(0xFFF7F7FB),
    );
  }

  static ThemeData get dark {
    final scheme = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark);
    return _base(scheme).copyWith(
      scaffoldBackgroundColor: const Color(0xFF0F1115),
    );
  }

  static ThemeData _base(ColorScheme scheme) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      brightness: scheme.brightness,
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        color: scheme.surfaceContainerHigh,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(
          color: scheme.onSurface,
          fontSize: 22,
          fontWeight: FontWeight.w700,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerHighest,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      textTheme: const TextTheme().apply(fontFamily: 'Roboto'),
    );
  }

  static BoxDecoration gradientCard({List<Color>? colors, double radius = 20}) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: colors ?? primaryGradient,
      ),
      borderRadius: BorderRadius.circular(radius),
    );
  }

  static Color streakColorForIntensity(int level, Brightness brightness) {
    final gradient = brightness == Brightness.dark ? streakGradientDark : streakGradientLight;
    if (level <= 0) {
      return brightness == Brightness.dark
          ? const Color(0xFF1B1F26)
          : const Color(0xFFEBEDF0);
    }
    final t = (level.clamp(1, 4)) / 4;
    return Color.lerp(gradient[0], gradient[1], t)!;
  }
}
