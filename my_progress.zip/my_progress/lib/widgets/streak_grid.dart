import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Renders a GitHub-contribution-style grid of daily productivity
/// intensity, most recent day last, columns representing weeks.
class StreakGrid extends StatelessWidget {
  /// Maps the start-of-day [DateTime] to an intensity level 0-4.
  final Map<DateTime, int> dailyIntensity;
  final int weeksToShow;

  const StreakGrid({
    super.key,
    required this.dailyIntensity,
    this.weeksToShow = 18,
  });

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final today = DateTime.now();
    final todayNormalized = DateTime(today.year, today.month, today.day);

    // Align the grid so the last column ends on the current week.
    final daysBack = weeksToShow * 7 - 1;
    final startDay = todayNormalized.subtract(Duration(days: daysBack));
    final startOfWeek = startDay.subtract(Duration(days: startDay.weekday % 7));

    final columns = <List<DateTime>>[];
    for (int w = 0; w < weeksToShow; w++) {
      final week = <DateTime>[];
      for (int d = 0; d < 7; d++) {
        week.add(startOfWeek.add(Duration(days: w * 7 + d)));
      }
      columns.add(week);
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      reverse: true,
      child: Row(
        children: columns.map((week) {
          return Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Column(
              children: week.map((day) {
                final isFuture = day.isAfter(todayNormalized);
                final level = isFuture ? -1 : (dailyIntensity[day] ?? 0);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Tooltip(
                    message: isFuture
                        ? ''
                        : '${day.month}/${day.day}: level $level',
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: isFuture
                            ? Colors.transparent
                            : AppTheme.streakColorForIntensity(level, brightness),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          );
        }).toList(),
      ),
    );
  }
}
