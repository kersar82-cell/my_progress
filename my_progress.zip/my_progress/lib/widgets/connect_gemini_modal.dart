import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/gemini_service.dart';
import '../theme/app_theme.dart';

/// Shown when the embedded free-tier quota is exhausted. Walks the
/// user through generating and saving their own Gemini key.
///
/// Call [ConnectGeminiModal.show] rather than pushing this directly -
/// it wires up the clipboard-detection lifecycle observer for you.
class ConnectGeminiModal extends StatefulWidget {
  const ConnectGeminiModal({super.key});

  static Future<bool?> show(BuildContext context) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const ConnectGeminiModal(),
    );
  }

  @override
  State<ConnectGeminiModal> createState() => _ConnectGeminiModalState();
}

class _ConnectGeminiModalState extends State<ConnectGeminiModal>
    with WidgetsBindingObserver {
  final _controller = TextEditingController();
  bool _obscure = true;
  bool _saving = false;
  String? _detectedClipboardKey;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // When the user returns from AI Studio in their browser, check
    // whether they copied a key so we can offer a one-tap fill.
    if (state == AppLifecycleState.resumed) {
      _checkClipboardForKey();
    }
  }

  Future<void> _checkClipboardForKey() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim();
    if (text != null && text.startsWith('AIzaSy') && text.length >= 30) {
      if (mounted) setState(() => _detectedClipboardKey = text);
    }
  }

  void _applyDetectedKey() {
    if (_detectedClipboardKey == null) return;
    _controller.text = _detectedClipboardKey!;
    setState(() {
      _obscure = false;
      _detectedClipboardKey = null;
    });
  }

  Future<void> _openApiKeyPage() async {
    final uri = Uri.parse('https://aistudio.google.com/app/apikey');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _saveKey() async {
    final key = _controller.text.trim();
    if (!GeminiService.instance.looksLikeValidKey(key)) {
      setState(() => _error = 'That doesn\'t look like a valid Gemini key.');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    await GeminiService.instance.saveCustomKey(key);
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: scheme.outlineVariant,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Unlock Unlimited Free AI Chat',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Connect your free personal Google Gemini key in 30 seconds.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
              ),
              const SizedBox(height: 20),
              _TrustBadge(
                emoji: '🟢',
                text: '100% free from Google (no hidden charges)',
              ),
              const SizedBox(height: 10),
              _TrustBadge(
                emoji: '🔒',
                text: 'Stored encrypted on your device only',
              ),
              const SizedBox(height: 10),
              _TrustBadge(
                emoji: '💳',
                text: 'No credit card or payment info required',
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _openApiKeyPage,
                  icon: const Icon(Icons.open_in_new, size: 18),
                  label: const Text('Get Free API Key'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: scheme.primary,
                    foregroundColor: scheme.onPrimary,
                  ),
                ),
              ),
              if (_detectedClipboardKey != null) ...[
                const SizedBox(height: 14),
                InkWell(
                  onTap: _applyDetectedKey,
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.success.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.success.withValues(alpha: 0.4)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.auto_awesome, color: AppTheme.success, size: 20),
                        const SizedBox(width: 10),
                        const Expanded(
                          child: Text(
                            'Gemini Key Detected! Tap to Auto-Fill & Save',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 18),
              Text('Or paste your key manually', style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(height: 8),
              TextField(
                controller: _controller,
                obscureText: _obscure,
                decoration: InputDecoration(
                  hintText: 'AIzaSy...',
                  errorText: _error,
                  suffixIcon: IconButton(
                    icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saving ? null : _saveKey,
                  child: _saving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Save Key'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrustBadge extends StatelessWidget {
  final String emoji;
  final String text;
  const _TrustBadge({required this.emoji, required this.text});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w500))),
          const Icon(Icons.check_circle, color: AppTheme.success, size: 18),
        ],
      ),
    );
  }
}
