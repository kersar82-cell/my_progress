import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../services/gemini_service.dart';
import '../../services/hive_service.dart';
import '../../services/secure_storage_service.dart';
import '../../widgets/connect_gemini_modal.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _hasCustomKey = false;
  int _remainingFree = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final hasKey = await GeminiService.instance.isUsingCustomKey;
    final remaining = await GeminiService.instance.remainingFreeQueries();
    setState(() {
      _hasCustomKey = hasKey;
      _remainingFree = remaining;
      _loading = false;
    });
  }

  Future<void> _removeKey() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove personal API key?'),
        content: const Text(
          'You will fall back to the limited free tier using the app\'s shared key.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Remove')),
        ],
      ),
    );
    if (confirmed == true) {
      await GeminiService.instance.removeCustomKey();
      await _refresh();
      if (mounted) Fluttertoast.showToast(msg: 'Personal key removed');
    }
  }

  Future<void> _connectKey() async {
    final connected = await ConnectGeminiModal.show(context);
    if (connected == true) await _refresh();
  }

  Future<void> _resetSecurity() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset security data?'),
        content: const Text(
          'This clears your saved API key and free-query counter from secure storage. '
          'Your logs and chat history are not affected.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await SecureStorageService.instance.wipeAll();
      await _refresh();
      if (mounted) Fluttertoast.showToast(msg: 'Security data reset');
    }
  }

  Future<void> _clearChat() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear AI chat history?'),
        content: const Text('This permanently deletes the entire conversation thread.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear')),
        ],
      ),
    );
    if (confirmed == true) {
      await HiveService.instance.clearChatThread();
      if (mounted) Fluttertoast.showToast(msg: 'Chat history cleared');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile & Settings')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              children: [
                _SectionHeader(title: 'Gemini AI'),
                Card(
                  child: Column(
                    children: [
                      ListTile(
                        leading: Icon(
                          _hasCustomKey ? Icons.verified_user_rounded : Icons.timer_outlined,
                          color: _hasCustomKey ? Colors.green : null,
                        ),
                        title: Text(_hasCustomKey ? 'Personal key connected' : 'Using shared free tier'),
                        subtitle: Text(
                          _hasCustomKey
                              ? 'Unlimited queries billed to your Google account'
                              : '$_remainingFree of ${GeminiService.freeQueryLimit} free queries remaining',
                        ),
                      ),
                      const Divider(height: 1),
                      if (_hasCustomKey)
                        ListTile(
                          leading: const Icon(Icons.delete_outline_rounded),
                          title: const Text('Remove personal key'),
                          onTap: _removeKey,
                        )
                      else
                        ListTile(
                          leading: const Icon(Icons.key_rounded),
                          title: const Text('Connect your own Gemini key'),
                          onTap: _connectKey,
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                _SectionHeader(title: 'Security status'),
                Card(
                  child: Column(
                    children: const [
                      ListTile(
                        leading: Icon(Icons.enhanced_encryption_rounded, color: Colors.green),
                        title: Text('API keys stored in hardware-backed keychain'),
                        subtitle: Text('flutter_secure_storage · never written to Hive'),
                      ),
                      Divider(height: 1),
                      ListTile(
                        leading: Icon(Icons.lock_rounded, color: Colors.green),
                        title: Text('Sensitive notes encrypted at rest'),
                        subtitle: Text('AES-256-CBC, device-derived key'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                _SectionHeader(title: 'Data'),
                Card(
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.chat_bubble_outline_rounded),
                        title: const Text('Clear AI chat history'),
                        onTap: _clearChat,
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: Icon(Icons.warning_amber_rounded,
                            color: Theme.of(context).colorScheme.error),
                        title: const Text('Reset security data'),
                        subtitle: const Text('Clears saved key and query counter'),
                        onTap: _resetSecurity,
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 4),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.8,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
