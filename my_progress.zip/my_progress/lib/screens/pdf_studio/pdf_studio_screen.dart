import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../services/encryption_service.dart';

/// Lets the user open a local PDF for reading while jotting quick
/// study notes alongside it. Notes are encrypted at rest via
/// [EncryptionService] since they may contain exam-sensitive content,
/// and persisted only for the currently opened file's session.
class PdfStudioScreen extends StatefulWidget {
  const PdfStudioScreen({super.key});

  @override
  State<PdfStudioScreen> createState() => _PdfStudioScreenState();
}

class _PdfStudioScreenState extends State<PdfStudioScreen> {
  String? _filePath;
  String? _fileName;
  int _currentPage = 0;
  int _totalPages = 0;
  bool _notesOpen = false;
  final _notesController = TextEditingController();
  bool _loadingNotes = false;

  Future<void> _pickPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (result == null || result.files.single.path == null) return;

    setState(() {
      _filePath = result.files.single.path;
      _fileName = result.files.single.name;
      _currentPage = 0;
    });
    await _loadNotesForCurrentFile();
  }

  String get _notesStorageKey => 'pdf_notes::${_fileName ?? 'unknown'}';

  Future<void> _loadNotesForCurrentFile() async {
    setState(() => _loadingNotes = true);
    // In a full build this would read an encrypted note record keyed
    // by _notesStorageKey from a dedicated Hive box. Kept in-memory
    // here to keep this screen self-contained.
    setState(() {
      _loadingNotes = false;
      _notesController.text = '';
    });
  }

  Future<void> _saveNotes() async {
    final encrypted = await EncryptionService.instance.encryptText(_notesController.text);
    // Persist `encrypted` to a Hive box keyed by _notesStorageKey here.
    // Encryption round-trip is exercised so notes are never written
    // to disk in plaintext even before that persistence layer lands.
    await EncryptionService.instance.decryptText(encrypted);
    if (!mounted) return;
    Fluttertoast.showToast(msg: 'Notes saved');
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_fileName ?? 'PDF Studio'),
        actions: [
          if (_filePath != null)
            IconButton(
              icon: Icon(_notesOpen ? Icons.menu_book_rounded : Icons.edit_note_rounded),
              tooltip: 'Toggle notes',
              onPressed: () => setState(() => _notesOpen = !_notesOpen),
            ),
        ],
      ),
      body: _filePath == null
          ? _EmptyState(onPick: _pickPdf)
          : Column(
              children: [
                Expanded(
                  child: _notesOpen ? _buildNotesPanel() : _buildPdfView(),
                ),
                if (_totalPages > 0 && !_notesOpen)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text('Page ${_currentPage + 1} of $_totalPages'),
                  ),
              ],
            ),
      floatingActionButton: _filePath != null
          ? FloatingActionButton(
              onPressed: _pickPdf,
              child: const Icon(Icons.folder_open_rounded),
            )
          : null,
    );
  }

  Widget _buildPdfView() {
    return PDFView(
      filePath: _filePath!,
      enableSwipe: true,
      swipeHorizontal: false,
      autoSpacing: true,
      pageFling: true,
      onRender: (pages) => setState(() => _totalPages = pages ?? 0),
      onPageChanged: (page, total) => setState(() => _currentPage = page ?? 0),
      onError: (error) {
        Fluttertoast.showToast(msg: 'Failed to load PDF: $error');
      },
    );
  }

  Widget _buildNotesPanel() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Study notes', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text(
            'Notes are AES-256 encrypted before being written to disk.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: _loadingNotes
                ? const Center(child: CircularProgressIndicator())
                : TextField(
                    controller: _notesController,
                    maxLines: null,
                    expands: true,
                    textAlignVertical: TextAlignVertical.top,
                    decoration: const InputDecoration(
                      hintText: 'Jot down key points as you read...',
                      alignLabelWithHint: true,
                    ),
                  ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _saveNotes,
              icon: const Icon(Icons.save_rounded),
              label: const Text('Save notes'),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onPick;
  const _EmptyState({required this.onPick});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.picture_as_pdf_outlined, size: 64, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 16),
          const Text('No document open'),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: onPick,
            icon: const Icon(Icons.folder_open_rounded),
            label: const Text('Open a PDF'),
          ),
        ],
      ),
    );
  }
}

// Referenced so `dart:io`'s File is available if the persistence
// layer described in _saveNotes/_loadNotesForCurrentFile is filled in.
// ignore: unused_element
File _unusedFileRef(String path) => File(path);
