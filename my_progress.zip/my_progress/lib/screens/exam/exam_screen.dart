import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../models/log_entry.dart';
import '../../services/hive_service.dart';

/// An exam's countdown/progress is derived from a [LogEntry] of type
/// [LogType.exam]: `timestamp` is the exam date, `durationMinutes`
/// stores 0-100 study progress percent (reused field to avoid a
/// second Hive model), and `subject` is the exam name.
class ExamScreen extends StatefulWidget {
  const ExamScreen({super.key});

  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  List<LogEntry> get _exams {
    final all = HiveService.instance.allLogEntries.where((e) => e.type == LogType.exam).toList();
    all.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return all;
  }

  void _openAddExamSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddExamSheet(
        onSave: (entry) async {
          await HiveService.instance.addLogEntry(entry);
          if (mounted) setState(() {});
        },
      ),
    );
  }

  Future<void> _updateProgress(LogEntry exam, double progress) async {
    exam.durationMinutes = progress.round();
    await HiveService.instance.updateLogEntry(exam);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final exams = _exams;
    return Scaffold(
      appBar: AppBar(title: const Text('Exams')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddExamSheet,
        icon: const Icon(Icons.add),
        label: const Text('Exam'),
      ),
      body: exams.isEmpty
          ? const Center(child: Text('No exams tracked yet.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              itemCount: exams.length,
              itemBuilder: (context, i) => _ExamCard(
                exam: exams[i],
                onProgressChanged: (p) => _updateProgress(exams[i], p),
              ),
            ),
    );
  }
}

class _ExamCard extends StatelessWidget {
  final LogEntry exam;
  final ValueChanged<double> onProgressChanged;
  const _ExamCard({required this.exam, required this.onProgressChanged});

  @override
  Widget build(BuildContext context) {
    final daysLeft = exam.timestamp.difference(DateTime.now()).inDays;
    final progress = (exam.durationMinutes ?? 0).clamp(0, 100) / 100;
    final scheme = Theme.of(context).colorScheme;

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    exam.subject ?? exam.title,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: daysLeft < 0
                        ? scheme.errorContainer
                        : scheme.primaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    daysLeft < 0 ? 'Past' : '$daysLeft days left',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: daysLeft < 0
                          ? scheme.onErrorContainer
                          : scheme.onPrimaryContainer,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              DateFormat('EEEE, MMM d, yyyy').format(exam.timestamp),
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Text('Study progress', style: Theme.of(context).textTheme.labelLarge),
                const Spacer(),
                Text('${(exam.durationMinutes ?? 0).clamp(0, 100)}%'),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 10,
                backgroundColor: scheme.surfaceContainerHighest,
              ),
            ),
            Slider(
              value: (exam.durationMinutes ?? 0).clamp(0, 100).toDouble(),
              min: 0,
              max: 100,
              divisions: 20,
              onChanged: onProgressChanged,
            ),
          ],
        ),
      ),
    );
  }
}

class _AddExamSheet extends StatefulWidget {
  final ValueChanged<LogEntry> onSave;
  const _AddExamSheet({required this.onSave});

  @override
  State<_AddExamSheet> createState() => _AddExamSheetState();
}

class _AddExamSheetState extends State<_AddExamSheet> {
  final _nameController = TextEditingController();
  DateTime _date = DateTime.now().add(const Duration(days: 7));

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  void _save() {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;
    final entry = LogEntry(
      id: const Uuid().v4(),
      title: name,
      subject: name,
      type: LogType.exam,
      timestamp: _date,
      durationMinutes: 0,
    );
    widget.onSave(entry);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('New exam', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(hintText: 'Exam / subject name'),
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(DateFormat('EEEE, MMM d, yyyy').format(_date)),
              trailing: const Icon(Icons.calendar_today_rounded),
              onTap: _pickDate,
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(onPressed: _save, child: const Text('Add exam')),
            ),
          ],
        ),
      ),
    );
  }
}
