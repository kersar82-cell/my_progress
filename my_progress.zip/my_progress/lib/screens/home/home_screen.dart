import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../models/log_entry.dart';
import '../../services/hive_service.dart';
import '../../services/categorization_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/streak_grid.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _uuid = const Uuid();

  List<LogEntry> get _entries => HiveService.instance.allLogEntries;

  Map<DateTime, int> get _dailyIntensity {
    final minutesByDay = CategorizationService.instance.dailyMinutes(_entries);
    return minutesByDay.map(
      (day, minutes) => MapEntry(day, CategorizationService.instance.intensityForMinutes(minutes)),
    );
  }

  void _openQuickLogSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _QuickLogSheet(
        onSave: (entry) async {
          await HiveService.instance.addLogEntry(entry);
          if (mounted) setState(() {});
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final todayEntries = HiveService.instance.logEntriesForDay(today);
    final todayMinutes = todayEntries.fold<int>(0, (sum, e) => sum + (e.durationMinutes ?? 0));

    return Scaffold(
      appBar: AppBar(title: const Text('Today')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openQuickLogSheet,
        icon: const Icon(Icons.add),
        label: const Text('Log'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => setState(() {}),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: AppTheme.gradientCard(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    DateFormat('EEEE, MMM d').format(today),
                    style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '$todayMinutes min logged today',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${todayEntries.length} ${todayEntries.length == 1 ? 'entry' : 'entries'}',
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text('Activity streak', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: StreakGrid(dailyIntensity: _dailyIntensity),
              ),
            ),
            const SizedBox(height: 20),
            Text('Recent activity', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            if (_entries.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: Text('No entries yet. Tap "Log" to get started.')),
              )
            else
              ..._entries.take(10).map((e) => _LogTile(entry: e)),
          ],
        ),
      ),
    );
  }
}

class _LogTile extends StatelessWidget {
  final LogEntry entry;
  const _LogTile({required this.entry});

  IconData get _icon {
    switch (entry.type) {
      case LogType.study:
        return Icons.menu_book_rounded;
      case LogType.task:
        return Icons.check_circle_outline_rounded;
      case LogType.exam:
        return Icons.event_note_rounded;
      case LogType.other:
        return Icons.bolt_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(_icon),
        title: Text(entry.title),
        subtitle: Text(
          [
            if (entry.subject != null) entry.subject!,
            DateFormat('MMM d, h:mm a').format(entry.timestamp),
          ].join(' · '),
        ),
        trailing: entry.durationMinutes != null ? Text('${entry.durationMinutes}m') : null,
      ),
    );
  }
}

class _QuickLogSheet extends StatefulWidget {
  final ValueChanged<LogEntry> onSave;
  const _QuickLogSheet({required this.onSave});

  @override
  State<_QuickLogSheet> createState() => _QuickLogSheetState();
}

class _QuickLogSheetState extends State<_QuickLogSheet> {
  final _titleController = TextEditingController();
  final _minutesController = TextEditingController();
  final _subjectController = TextEditingController();
  LogType _type = LogType.study;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Quick log', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(hintText: 'What did you do?'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _subjectController,
              decoration: const InputDecoration(hintText: 'Subject (optional)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _minutesController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: 'Minutes spent'),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: LogType.values.map((t) {
                return ChoiceChip(
                  label: Text(t.name),
                  selected: _type == t,
                  onSelected: (_) => setState(() => _type = t),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _save,
                child: const Text('Save entry'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _save() {
    final title = _titleController.text.trim();
    if (title.isEmpty) return;
    final entry = LogEntry(
      id: const Uuid().v4(),
      title: title,
      type: _type,
      timestamp: DateTime.now(),
      durationMinutes: int.tryParse(_minutesController.text.trim()),
      subject: _subjectController.text.trim().isEmpty ? null : _subjectController.text.trim(),
    );
    widget.onSave(entry);
    Navigator.of(context).pop();
  }
}
