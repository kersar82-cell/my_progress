import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_generative_ai/google_generative_ai.dart' as gen;
import 'package:uuid/uuid.dart';
import '../../models/chat_message.dart';
import '../../services/hive_service.dart';
import '../../services/gemini_service.dart';
import '../../widgets/connect_gemini_modal.dart';
import '../../theme/app_theme.dart';

/// The app's single, persistent AI conversation. No thread list, no
/// "new chat" button by design - one continuous history stored in
/// the `ai_chat_box` Hive box.
class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final _inputController = TextEditingController();
  final _scrollController = ScrollController();
  final _uuid = const Uuid();
  bool _sending = false;
  int? _remainingFree;
  bool _usingCustomKey = false;

  List<ChatMessage> get _messages => HiveService.instance.chatHistory;

  @override
  void initState() {
    super.initState();
    _refreshQuotaBadge();
  }

  Future<void> _refreshQuotaBadge() async {
    final remaining = await GeminiService.instance.remainingFreeQueries();
    final custom = await GeminiService.instance.isUsingCustomKey;
    if (mounted) {
      setState(() {
        _remainingFree = remaining;
        _usingCustomKey = custom;
      });
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  List<gen.Content> _historyAsContent() {
    return _messages
        .where((m) => !m.isPending && !m.isError)
        .map((m) => m.role == MessageRole.user
            ? gen.Content.text(m.content)
            : gen.Content.model([gen.TextPart(m.content)]))
        .toList();
  }

  Future<void> _send() async {
    final text = _inputController.text.trim();
    if (text.isEmpty || _sending) return;

    final historyForRequest = _historyAsContent();

    final userMessage = ChatMessage(
      id: _uuid.v4(),
      content: text,
      role: MessageRole.user,
      timestamp: DateTime.now(),
    );
    await HiveService.instance.addChatMessage(userMessage);
    _inputController.clear();

    final pendingId = _uuid.v4();
    final pendingMessage = ChatMessage(
      id: pendingId,
      content: '',
      role: MessageRole.ai,
      timestamp: DateTime.now(),
      isPending: true,
    );
    await HiveService.instance.addChatMessage(pendingMessage);

    setState(() => _sending = true);
    _scrollToBottom();

    try {
      final result = await GeminiService.instance.sendMessage(text, history: historyForRequest);
      pendingMessage.content = result.text;
      pendingMessage.isPending = false;
      await HiveService.instance.updateChatMessage(pendingMessage);
      await _refreshQuotaBadge();
    } on GeminiQuotaExceededException {
      pendingMessage.isPending = false;
      pendingMessage.isError = true;
      pendingMessage.content = 'Free query limit reached.';
      await HiveService.instance.updateChatMessage(pendingMessage);
      if (mounted) {
        final connected = await ConnectGeminiModal.show(context);
        if (connected == true) {
          await _refreshQuotaBadge();
        }
      }
    } on GeminiRateLimitException catch (e) {
      pendingMessage.isPending = false;
      pendingMessage.isError = true;
      pendingMessage.content = e.message;
      await HiveService.instance.updateChatMessage(pendingMessage);
      Fluttertoast.showToast(msg: e.message);
    } catch (e) {
      pendingMessage.isPending = false;
      pendingMessage.isError = true;
      pendingMessage.content = 'Something went wrong. Please try again.';
      await HiveService.instance.updateChatMessage(pendingMessage);
      Fluttertoast.showToast(msg: 'Error: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _sending = false);
      _scrollToBottom();
    }
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final messages = _messages;
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Assistant'),
        actions: [
          if (!_usingCustomKey && _remainingFree != null)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Free AI Queries: $_remainingFree/${GeminiService.freeQueryLimit} Left',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: messages.isEmpty
                ? const Center(child: Text('Ask me anything about your studies or tasks.'))
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: messages.length,
                    itemBuilder: (context, i) => _ChatBubble(message: messages[i]),
                  ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _inputController,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: const InputDecoration(hintText: 'Message the assistant...'),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: _sending ? null : _send,
              icon: _sending
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.arrow_upward_rounded),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatBubble extends StatelessWidget {
  final ChatMessage message;
  const _ChatBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final scheme = Theme.of(context).colorScheme;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          gradient: isUser ? const LinearGradient(colors: AppTheme.primaryGradient) : null,
          color: isUser
              ? null
              : (message.isError ? scheme.errorContainer : scheme.surfaceContainerHigh),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isUser ? 18 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 18),
          ),
        ),
        child: message.isPending
            ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : isUser
                ? Text(message.content, style: const TextStyle(color: Colors.white))
                : MarkdownBody(
                    data: message.content,
                    styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)),
                  ),
      ),
    );
  }
}
