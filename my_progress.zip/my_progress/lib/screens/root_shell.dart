import 'package:flutter/material.dart';
import '../widgets/animated_bottom_nav.dart';
import 'home/home_screen.dart';
import 'exam/exam_screen.dart';
import 'pdf_studio/pdf_studio_screen.dart';
import 'ai_chat/ai_chat_screen.dart';
import 'profile/profile_screen.dart';

/// Hosts the bottom-navigation shell. Screens are kept alive via
/// [IndexedStack] so the AI chat thread and PDF viewer state survive
/// switching tabs.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  static const _screens = [
    HomeScreen(),
    ExamScreen(),
    PdfStudioScreen(),
    AiChatScreen(),
    ProfileScreen(),
  ];

  static const _items = [
    NavItemData(icon: Icons.home_outlined, activeIcon: Icons.home_rounded, label: 'Home'),
    NavItemData(icon: Icons.event_note_outlined, activeIcon: Icons.event_note_rounded, label: 'Exams'),
    NavItemData(icon: Icons.picture_as_pdf_outlined, activeIcon: Icons.picture_as_pdf_rounded, label: 'PDF'),
    NavItemData(icon: Icons.smart_toy_outlined, activeIcon: Icons.smart_toy_rounded, label: 'AI Chat'),
    NavItemData(icon: Icons.person_outline_rounded, activeIcon: Icons.person_rounded, label: 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: IndexedStack(index: _index, children: _screens),
      ),
      bottomNavigationBar: AnimatedBottomNav(
        currentIndex: _index,
        items: _items,
        onTap: (i) => setState(() => _index = i),
      ),
    );
  }
}
